package actionPack;

import environmentPack.Coordinate;

public class ActionStatePair {

	public Coordinate Action;
	public double Value;

	public ActionStatePair(Coordinate action, double value) {

		Action = action;
		Value = value;

	}

}
