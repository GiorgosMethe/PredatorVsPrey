package actionPack;

import java.util.Vector;

public class ActionValues {

	public Vector<ActionStatePair> sAp = new Vector<ActionStatePair>();

	public ActionValues(Vector<ActionStatePair> actVal) {
		this.sAp = actVal;
	}

}
